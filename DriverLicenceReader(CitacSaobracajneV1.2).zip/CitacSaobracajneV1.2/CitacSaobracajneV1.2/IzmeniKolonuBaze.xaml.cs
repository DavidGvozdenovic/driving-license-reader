﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CitacSaobracajneV1._2
{
    /// <summary>
    /// Interaction logic for IzmeniKolonuBaze.xaml
    /// </summary>
    public partial class IzmeniKolonuBaze : Window
    {
        MainWindow glavniProzor = new MainWindow();
        private MainWindow mainWindow;
        public IzmeniKolonuBaze(MainWindow main)
        {
            InitializeComponent();
            mainWindow = main;
        }

        private void Odustani_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Izmeni_Click(object sender, RoutedEventArgs e)
        {
            object selectedRowData = mainWindow.GetSelectedRowData();

            // Replace the connection string with your server name
            string serverName = "PERIC - PC";
            string connectionString = "Data Source=" + serverName + ";Initial Catalog=CitacSaobracajne;Integrated Security=True";


            if (selectedRowData != null)
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Create an SQL UPDATE query to update data in the database
                    string updateQuery = "UPDATE PodaciSaobracajneDozvole SET DrzavaIzdavanja = '" + drzavaIzdavanja.Text + "', DokumentIzdao = @DokumentIzdao, DatumIzdavanja = @DatumIzdavanja, DatumIsteka = @DatumIsteka, ZabranaOtudjenjaVozila = @ZabranaOtudjenjaVozila, " +
                                         "BrojDokumenta = @BrojDokumenta, SerijskiBroj = @SerijskiBroj, Vlasnik = @Vlasnik, ImeVlasnika = @ImeVlasnika, JmbgVlasnika = @JmbgVlasnika, AdresaVlasnika = @AdresaVlasnika, Korisnik = @Korisnik, " +
                                         "ImeKorisnik = @ImeKorisnik, JmbgKorisnik = @JmbgKorisnik, AdresaKorisnika = @AdresaKorisnika, RegistarskiBroj = @RegistarskiBroj, DatumPrveRegistracije = @DatumPrveRegistracije, " +
                                         "Marka = @Marka, Model = @Model, GodinaProizvodnje = @GodinaProizvodnje, Tip = @Tip, Boja = @Boja, BrojSasije = @BrojSasije, BrojMotora = @BrojMotora, " +
                                         "SnagaMotora = @SnagaMotora, Masa = @Masa, ZapreminaMotora = @ZapreminaMotora, NosivostVozila = @NosivostVozila, OdnosSnagaMasa = @OdnosSnagaMasa, BrojOsovina = @BrojOsovina, " +
                                         "NajvecaDozvoljenaMasa = @NajvecaDozvoljenaMasa, BrojMestaZaSedenje = @BrojMestaZaSedenje, BrojMestaZaStajanje = @BrojMestaZaStajanje, HomologacijskaOznaka = @HomologacijskaOznaka, " +
                                         "VrstaVozila = @VrstaVozila, PogonskoGorivo = @PogonskoGorivo WHERE PodaciID = '" + selectedRowData + "'";

                    //konvertovanje datuma
                    var datum_izdavanja = Convert.ToDateTime(datumIzdavanja.Text);
                    var datum_isteka = datum_izdavanja.AddYears(1);
                    var datum_prve_registracije = Convert.ToDateTime(datumPrveRegistracije.Text);


                    using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                    {
                        // Set the parameters using TextBox.Text values
                        //cmd.Parameters.AddWithValue("@DrzavaIzdavanja", drzavaIzdavanja.Text);
                        cmd.Parameters.AddWithValue("@DokumentIzdao", dokumentIzdao.Text);
                        cmd.Parameters.AddWithValue("@DatumIzdavanja", Convert.ToDateTime(datumIzdavanja.Text));
                        cmd.Parameters.AddWithValue("@DatumIsteka", datum_isteka);
                        cmd.Parameters.AddWithValue("@ZabranaOtudjenjaVozila", zabranjaOtudjenja.Text);
                        cmd.Parameters.AddWithValue("@BrojDokumenta", brojDokumenta.Text);
                        cmd.Parameters.AddWithValue("@SerijskiBroj", serijskiBroj.Text);
                        cmd.Parameters.AddWithValue("@Vlasnik", vlasnik.Text);
                        cmd.Parameters.AddWithValue("@ImeVlasnika", imeVlasnik.Text);
                        cmd.Parameters.AddWithValue("@JmbgVlasnika", jmbgVlasnika.Text);
                        cmd.Parameters.AddWithValue("@AdresaVlasnika", adresaVlasnika.Text);
                        cmd.Parameters.AddWithValue("@Korisnik", korisnik.Text);
                        cmd.Parameters.AddWithValue("@ImeKorisnik", imeKorisnika.Text);
                        cmd.Parameters.AddWithValue("@JmbgKorisnik", jmbgKorisnika.Text);
                        cmd.Parameters.AddWithValue("@AdresaKorisnika", adresaKorisnika.Text);
                        cmd.Parameters.AddWithValue("@RegistarskiBroj", registarskiBroj.Text);
                        cmd.Parameters.AddWithValue("@DatumPrveRegistracije", datum_prve_registracije);
                        cmd.Parameters.AddWithValue("@Marka", marka.Text);
                        cmd.Parameters.AddWithValue("@Model", model.Text);
                        cmd.Parameters.AddWithValue("@GodinaProizvodnje", godinaProizvodnje.Text);
                        cmd.Parameters.AddWithValue("@Tip", tip.Text);
                        cmd.Parameters.AddWithValue("@Boja", boja.Text);
                        cmd.Parameters.AddWithValue("@BrojSasije", brojSasije.Text);
                        cmd.Parameters.AddWithValue("@BrojMotora", brojMotora.Text);
                        cmd.Parameters.AddWithValue("@SnagaMotora", snagaMotora.Text);
                        cmd.Parameters.AddWithValue("@Masa", masaVozila.Text);
                        cmd.Parameters.AddWithValue("@ZapreminaMotora", zapreminaMotora.Text);
                        cmd.Parameters.AddWithValue("@NosivostVozila", nosivostVozila.Text);
                        cmd.Parameters.AddWithValue("@OdnosSnagaMasa", odnosSnagaMasa.Text);
                        cmd.Parameters.AddWithValue("@BrojOsovina", brojOsovina.Text);
                        cmd.Parameters.AddWithValue("@NajvecaDozvoljenaMasa", najvecaDozovljenaMasa.Text);
                        cmd.Parameters.AddWithValue("@BrojMestaZaSedenje", brojMestaZaSedenje.Text);
                        cmd.Parameters.AddWithValue("@BrojMestaZaStajanje", brojMestaZaStajanje.Text);
                        cmd.Parameters.AddWithValue("@HomologacijskaOznaka", homologacijskaOznaka.Text);
                        cmd.Parameters.AddWithValue("@VrstaVozila", vrstaVozila.Text);
                        cmd.Parameters.AddWithValue("@PogonskoGorivo", pogonskoGorivo.Text);

                        cmd.ExecuteNonQuery();

                        
                    }
                }
                MessageBox.Show("Podaci uspešno promenjeni.", "Uspešna komunikacija", MessageBoxButton.OK, MessageBoxImage.Information);
                ispisiBazu();
                this.Close();
            }
            else
            {
                // Handle the case when there is no selected row
            }

            




        }


        private void ispisiBazu()
        {
            //string imeUneteBaze = mainWindow.imeBaze.Text;

            string connectionString = "Data Source=PERIC-PC;Initial Catalog=CitacSaobracajne;Integrated Security=True";
            //connectionString = connectionString.Replace("Data Source=PERIC-PC", "Data Source=" + imeUneteBaze);
            string query = "SELECT * FROM PodaciSaobracajneDozvole";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);

                    mainWindow.prikazIzBaze.ItemsSource = dataTable.DefaultView;
                }
            }
        }
    }
}
