﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CitacSaobracajneV1._2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {

            InitializeComponent();
            //ispisiBazu();
        }

        private void UpisiUBazu_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(drzavaIzdavanja.Text) || string.IsNullOrEmpty(dokumentIzdao.Text) || string.IsNullOrEmpty(drzavaIzdavanja.Text)
                || string.IsNullOrEmpty(datumIsteka.Text) || string.IsNullOrEmpty(brojDokumenta.Text) || string.IsNullOrEmpty(serijskiBroj.Text)
                || string.IsNullOrEmpty(vlasnik.Text) || string.IsNullOrEmpty(imeVlasnik.Text) || string.IsNullOrEmpty(jmbgVlasnika.Text)
                || string.IsNullOrEmpty(adresaVlasnika.Text) || string.IsNullOrEmpty(registarskiBroj.Text) || string.IsNullOrEmpty(datumPrveRegistracije.Text)
                || string.IsNullOrEmpty(marka.Text) || string.IsNullOrEmpty(model.Text) || string.IsNullOrEmpty(godinaProizvodnje.Text)
                || string.IsNullOrEmpty(boja.Text) || string.IsNullOrEmpty(brojSasije.Text) || string.IsNullOrEmpty(brojMotora.Text)
                || string.IsNullOrEmpty(snagaMotora.Text) || string.IsNullOrEmpty(masaVozila.Text) || string.IsNullOrEmpty(zapreminaMotora.Text)
                || string.IsNullOrEmpty(nosivostVozila.Text) || string.IsNullOrEmpty(odnosSnagaMasa.Text) || string.IsNullOrEmpty(brojOsovina.Text)
                || string.IsNullOrEmpty(najvecaDozovljenaMasa.Text) || string.IsNullOrEmpty(brojMestaZaSedenje.Text) || string.IsNullOrEmpty(vrstaVozila.Text)
                || string.IsNullOrEmpty(pogonskoGorivo.Text))
            {
                MessageBox.Show("Obavezna polja su označena zvezdicom i moraju biti ispunjena!", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                try
                {
                    //unos imena servera preko textboxa
                    string imeUneteBaze = "PERIC-PC";
                    SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                    builder.DataSource = imeUneteBaze;
                    builder.InitialCatalog = "CitacSaobracajne";
                    builder.IntegratedSecurity = true;

                    //pravljenje konekcije sa unetim imenom servera
                    SqlConnection connection = new SqlConnection(builder.ToString());
                    connection.Open();

                    SqlCommand command = new SqlCommand("insert into PodaciSaobracajneDozvole (SifraVozila,DrzavaIzdavanja,DokumentIzdao,DatumIzdavanja,DatumIsteka,ZabranaOtudjenjaVozila,BrojDokumenta,SerijskiBroj,Vlasnik,ImeVlasnika,JmbgVlasnika,AdresaVlasnika,Korisnik,ImeKorisnik,JmbgKorisnik,AdresaKorisnika,RegistarskiBroj,DatumPrveRegistracije,Marka,Model,GodinaProizvodnje,Tip,Boja,BrojSasije,BrojMotora,SnagaMotora,Masa,ZapreminaMotora,NosivostVozila,OdnosSnagaMasa,BrojOsovina,NajvecaDozvoljenaMasa,BrojMestaZaSedenje,BrojMestaZaStajanje,HomologacijskaOznaka,VrstaVozila,PogonskoGorivo) values" +
                        "(@SifraVozila,@DrzavaIzdavanja,@DokumentIzdao,@DatumIzdavanja,@DatumIsteka,@ZabranaOtudjenjaVozila,@BrojDokumenta,@SerijskiBroj,@Vlasnik,@ImeVlasnika,@JmbgVlasnika,@AdresaVlasnika,@Korisnik,@ImeKorisnik,@JmbgKorisnik,@AdresaKorisnika,@RegistarskiBroj,@DatumPrveRegistracije,@Marka,@Model,@GodinaProizvodnje,@Tip,@Boja,@BrojSasije,@BrojMotora,@SnagaMotora,@Masa,@ZapreminaMotora,@NosivostVozila,@OdnosSnagaMasa,@BrojOsovina,@NajvecaDozvoljenaMasa,@BrojMestaZaSedenje,@BrojMestaZaStajanje,@HomologacijskaOznaka,@VrstaVozila,@PogonskoGorivo)", connection);
                    
                    //konvertovanje datuma
                    var datum_izdavanja = Convert.ToDateTime(datumIzdavanja.Text);
                    var datum_isteka = datum_izdavanja.AddYears(1);
                    var datum_prve_registracije = Convert.ToDateTime(datumPrveRegistracije.Text);



                    string query = "SELECT COALESCE(MAX(SifraVozila), 0) AS LastSifraVozila FROM PodaciSaobracajneDozvole";
                    SqlCommand command_getLastSifraVozila = new SqlCommand(query, connection);

                    // Execute the query to get the last SifraVozila
                    int lastSifraVozila = (int)command_getLastSifraVozila.ExecuteScalar();

                    //// Check if lastSifraVozila is 0 and set it to 1 in that case
                    //if (lastSifraVozila == 0)
                    //{
                    //    lastSifraVozila = 1;
                    //}





                    command.Parameters.AddWithValue("@SifraVozila", lastSifraVozila+1);
                    command.Parameters.AddWithValue("@DrzavaIzdavanja", drzavaIzdavanja.Text);
                    command.Parameters.AddWithValue("@DokumentIzdao", dokumentIzdao.Text);
                    command.Parameters.AddWithValue("@DatumIzdavanja", datum_izdavanja);
                    command.Parameters.AddWithValue("@DatumIsteka", datum_isteka);
                    command.Parameters.AddWithValue("@ZabranaOtudjenjaVozila", zabranjaOtudjenja.Text);
                    command.Parameters.AddWithValue("@BrojDokumenta", brojDokumenta.Text);
                    command.Parameters.AddWithValue("@SerijskiBroj", serijskiBroj.Text);
                    command.Parameters.AddWithValue("@Vlasnik", vlasnik.Text);
                    command.Parameters.AddWithValue("@ImeVlasnika", imeVlasnik.Text);
                    command.Parameters.AddWithValue("@JmbgVlasnika", jmbgVlasnika.Text);
                    command.Parameters.AddWithValue("@AdresaVlasnika", adresaVlasnika.Text);
                    command.Parameters.AddWithValue("@Korisnik", korisnik.Text);
                    command.Parameters.AddWithValue("@ImeKorisnik", imeKorisnika.Text);
                    command.Parameters.AddWithValue("@JmbgKorisnik", jmbgKorisnika.Text);
                    command.Parameters.AddWithValue("@AdresaKorisnika", adresaKorisnika.Text);
                    command.Parameters.AddWithValue("@RegistarskiBroj", registarskiBroj.Text);
                    command.Parameters.AddWithValue("@DatumPrveRegistracije", datum_prve_registracije);
                    command.Parameters.AddWithValue("@Marka", marka.Text);
                    command.Parameters.AddWithValue("@Model", model.Text);
                    command.Parameters.AddWithValue("@GodinaProizvodnje", godinaProizvodnje.Text);
                    command.Parameters.AddWithValue("@Tip", tip.Text);
                    command.Parameters.AddWithValue("@Boja", boja.Text);
                    command.Parameters.AddWithValue("@BrojSasije", brojSasije.Text);
                    command.Parameters.AddWithValue("@BrojMotora", brojMotora.Text);
                    command.Parameters.AddWithValue("@SnagaMotora", snagaMotora.Text);
                    command.Parameters.AddWithValue("@Masa", masaVozila.Text);
                    command.Parameters.AddWithValue("@ZapreminaMotora", zapreminaMotora.Text);
                    command.Parameters.AddWithValue("@NosivostVozila", nosivostVozila.Text);
                    command.Parameters.AddWithValue("@OdnosSnagaMasa", odnosSnagaMasa.Text);
                    command.Parameters.AddWithValue("@BrojOsovina", brojOsovina.Text);
                    command.Parameters.AddWithValue("@NajvecaDozvoljenaMasa", najvecaDozovljenaMasa.Text);
                    command.Parameters.AddWithValue("@BrojMestaZaSedenje", brojMestaZaSedenje.Text);
                    command.Parameters.AddWithValue("@BrojMestaZaStajanje", brojMestaZaStajanje.Text);
                    command.Parameters.AddWithValue("@HomologacijskaOznaka", homologacijskaOznaka.Text);
                    command.Parameters.AddWithValue("@VrstaVozila", vrstaVozila.Text);
                    command.Parameters.AddWithValue("@PogonskoGorivo", pogonskoGorivo.Text);

                    command.ExecuteNonQuery();
                    ispisiBazu();
                    MessageBox.Show("Podaci uspešno upisani u bazu.", "Uspešna komunikacija", MessageBoxButton.OK, MessageBoxImage.Information);


                    //ciscenje textboxova
                    //drzavaIzdavanja.Text = "";
                    obrisiUnetePodatke();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Desila se greška prilikom komunikacije sa serverom. Greška: " + ex.Message, "Upozorenje!", MessageBoxButton.OK, MessageBoxImage.Error);

                }
            }
            


        }
        private void OsiguranjaWindow_Click(object sender, RoutedEventArgs e)
        {
            Osiguranja svaOsiguranja = new Osiguranja();
            svaOsiguranja.Show();
            this.Close();
        }

        //private void PregledajBazu_Click(object sender, RoutedEventArgs e)
        //{
        //    //SqlConnection connection = new SqlConnection("Data Source=DESKTOP-0O727FT;Initial Catalog=CitacSaobracajne;Integrated Security=True");
        //    //connection.Open();
        //    //MessageBox.Show("Uspesna konekcija.", "Uspesna komunikacija", MessageBoxButton.OK, MessageBoxImage.Information);


        //    //SqlCommand cmd1 = new SqlCommand("Select * from  PodaciSaobracajneDozvole", connection);
        //    //SqlDataAdapter da = new SqlDataAdapter(cmd1);
        //    //DataTable dt = new DataTable();
        //    //da.Fill(dt);
        //    //prikazIzBaze.DataContext = dt;
        //    //MessageBox.Show("Uspesna ispisano.", "Uspesna komunikacija", MessageBoxButton.OK, MessageBoxImage.Information);


        //    string imeUneteBaze = imeBaze.Text;

        //    string connectionString = "Data Source=DESKTOP-0O727FT;Initial Catalog=CitacSaobracajne;Integrated Security=True";
        //    connectionString = connectionString.Replace("Data Source=DESKTOP-0O727FT", "Data Source=" + imeUneteBaze);
        //    string query = "SELECT * FROM PodaciSaobracajneDozvole";

        //    using (SqlConnection connection = new SqlConnection(connectionString))
        //    {
        //        connection.Open();

        //        using (SqlCommand command = new SqlCommand(query, connection))
        //        {
        //            SqlDataAdapter adapter = new SqlDataAdapter(command);
        //            DataTable dataTable = new DataTable();

        //            adapter.Fill(dataTable);

        //            prikazIzBaze.ItemsSource = dataTable.DefaultView;
        //        }
        //    }
        //}

        private void ispisiBazu()
        {
            //string imeUneteBaze = imeBaze.Text;

            string connectionString = "Data Source=PERIC-PC;Initial Catalog=CitacSaobracajne;Integrated Security=True";
            //connectionString = connectionString.Replace("Data Source=PERIC-PC", "Data Source=" + imeUneteBaze);


            string query = "SELECT * FROM PodaciSaobracajneDozvole";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);

                    prikazIzBaze.ItemsSource = dataTable.DefaultView;
                }
            }
        }
        private void obrisiUnetePodatke()
        {
            drzavaIzdavanja.Clear();
            drzavaIzdavanja.Clear();
            dokumentIzdao.Clear();
            datumIzdavanja.SelectedDate = null;
            datumIsteka.SelectedDate = null;
            zabranjaOtudjenja.Clear();
            brojDokumenta.Clear();
            serijskiBroj.Clear();
            vlasnik.Clear();
            imeVlasnik.Clear();
            jmbgVlasnika.Clear();
            adresaVlasnika.Clear();
            korisnik.Clear();
            imeKorisnika.Clear();
            jmbgKorisnika.Clear();
            adresaKorisnika.Clear();
            registarskiBroj.Clear();
            datumPrveRegistracije.SelectedDate = null;
            marka.Clear();
            model.Clear();
            godinaProizvodnje.Clear();
            tip.Clear();
            boja.Clear();
            brojSasije.Clear();
            brojMotora.Clear();
            snagaMotora.Clear();
            masaVozila.Clear();
            zapreminaMotora.Clear();
            nosivostVozila.Clear();
            odnosSnagaMasa.Clear();
            brojOsovina.Clear();
            najvecaDozovljenaMasa.Clear();
            brojMestaZaSedenje.Clear();
            brojMestaZaStajanje.Clear();
            homologacijskaOznaka.Clear();
            vrstaVozila.Clear();
            pogonskoGorivo.Clear();
        }
        private void PrometWindow_Click(object sender, RoutedEventArgs e)
        {
            Promet promet = new Promet();
            promet.Show();
            this.Close();
        }

        private void IzbrisiIzBaze_Click(object sender, RoutedEventArgs e)
        {
            var selectedRows = prikazIzBaze.SelectedItems;
            if (selectedRows.Count == 0)
            {
                MessageBox.Show("Niste izabrali nijednu kolonu.", "Upozorenje", MessageBoxButton.OK, MessageBoxImage.Information);

                // Handle the case where no row is selected
                return;
            }
            int selectedRowID = (int)((DataRowView)selectedRows[0]).Row["PodaciID"];

            //unos imena servera preko textboxa
            //string imeUneteBaze = imeBaze.Text;
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            //builder.DataSource = imeUneteBaze;
            builder.InitialCatalog = "CitacSaobracajne";
            builder.IntegratedSecurity = true;

            //pravljenje konekcije sa unetim imenom servera
            //SqlConnection connection = new SqlConnection(builder.ToString());
            using (SqlConnection connection = new SqlConnection(builder.ToString()))
            {
                connection.Open();

                string deleteQuery = "DELETE FROM PodaciSaobracajneDozvole WHERE PodaciID = @SelectedRowID";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@SelectedRowID", selectedRowID);
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Izabrana kolona uspesno obrisana.", "Uspesno", MessageBoxButton.OK, MessageBoxImage.Information);
                        ispisiBazu();
                        // The row was successfully deleted
                        // You can also update the DataGrid to reflect the change in the UI
                        // Reload the data or remove the deleted row from your data source.
                    }
                    else
                    {

                        // Handle the case where no rows were deleted (e.g., the ID didn't exist)
                    }
                }
            }
        }

        //private void OtvoriProzorZaIzmenu_Click(object sender, RoutedEventArgs e)
        //{
        //    var selectedRows = prikazIzBaze.SelectedItems;
        //    if (selectedRows.Count == 0)
        //    {
        //        MessageBox.Show("Niste izabrali nijednu kolonu.", "Upozorenje", MessageBoxButton.OK, MessageBoxImage.Information);

        //        // Handle the case where no row is selected
        //        return;
        //    }

        //    IzmeniKolonuBaze izmeniKolonuBaze = new IzmeniKolonuBaze();
        //    izmeniKolonuBaze.Show();

        //    int selectedRowID = (int)((DataRowView)selectedRows[0]).Row["PodaciID"];

        //    string imeUneteBaze = imeBaze.Text;

        //    string connectionString = "Data Source=DESKTOP-0O727FT;Initial Catalog=CitacSaobracajne;Integrated Security=True";
        //    connectionString = connectionString.Replace("Data Source=DESKTOP-0O727FT", "Data Source=" + imeUneteBaze);
        //    string query = "SELECT * FROM PodaciSaobracajneDozvole WHERE PodaciID = @SelectedRowID";


        //}

        //protected override void OnClosed(EventArgs e)
        //{
        //    base.OnClosed(e);

        //    Application.Current.Shutdown();
        //}

        private void OtvoriProzorZaIzmenu_Click(object sender, RoutedEventArgs e)
        {
            var selectedRows = prikazIzBaze.SelectedItems;
            if (selectedRows.Count == 0)
            {
                MessageBox.Show("Niste izabrali nijednu kolonu.", "Upozorenje", MessageBoxButton.OK, MessageBoxImage.Information);
                // Handle the case where no row is selected
                return;
            }

            // Create a new instance of the window
            IzmeniKolonuBaze izmeniKolonuBaze = new IzmeniKolonuBaze(this);

            // Assuming you have UI elements in the IzmeniKolonuBaze window for each field, you can set their values here
            int selectedRowID = (int)((DataRowView)selectedRows[0]).Row["PodaciID"];

            //string imeUneteBaze = imeBaze.Text;
            string connectionString = "Data Source=PERIC-PC;Initial Catalog=CitacSaobracajne;Integrated Security=True";
            connectionString = connectionString.Replace("Data Source=PERIC-PC", "Data Source=");
            string query = "SELECT * FROM PodaciSaobracajneDozvole WHERE PodaciID = @SelectedRowID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@SelectedRowID", selectedRowID);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            izmeniKolonuBaze.drzavaIzdavanja.Text = reader["DrzavaIzdavanja"].ToString();
                            izmeniKolonuBaze.dokumentIzdao.Text = reader["DokumentIzdao"].ToString();
                            izmeniKolonuBaze.datumIzdavanja.SelectedDate = reader["DatumIzdavanja"] as DateTime?;
                            izmeniKolonuBaze.datumIsteka.SelectedDate = reader["DatumIsteka"] as DateTime?;
                            izmeniKolonuBaze.zabranjaOtudjenja.Text = reader["ZabranaOtudjenjaVozila"].ToString();
                            izmeniKolonuBaze.brojDokumenta.Text = reader["BrojDokumenta"].ToString();
                            izmeniKolonuBaze.serijskiBroj.Text = reader["SerijskiBroj"].ToString();


                            izmeniKolonuBaze.vlasnik.Text = reader["Vlasnik"].ToString();
                            izmeniKolonuBaze.imeVlasnik.Text = reader["ImeVlasnika"].ToString();
                            izmeniKolonuBaze.jmbgVlasnika.Text = reader["JmbgVlasnika"].ToString();
                            izmeniKolonuBaze.adresaVlasnika.Text = reader["AdresaVlasnika"].ToString();
                            izmeniKolonuBaze.korisnik.Text = reader["Korisnik"].ToString();
                            izmeniKolonuBaze.imeKorisnika.Text = reader["ImeKorisnik"].ToString();
                            izmeniKolonuBaze.jmbgKorisnika.Text = reader["JmbgKorisnik"].ToString();
                            izmeniKolonuBaze.adresaKorisnika.Text = reader["AdresaKorisnika"].ToString();

                            izmeniKolonuBaze.registarskiBroj.Text = reader["RegistarskiBroj"].ToString();
                            izmeniKolonuBaze.datumPrveRegistracije.SelectedDate = DateTime.Parse(reader["DatumPrveRegistracije"].ToString());
                            izmeniKolonuBaze.marka.Text = reader["Marka"].ToString();
                            izmeniKolonuBaze.model.Text = reader["Model"].ToString();
                            izmeniKolonuBaze.godinaProizvodnje.Text = reader["GodinaProizvodnje"].ToString();
                            izmeniKolonuBaze.tip.Text = reader["Tip"].ToString();
                            izmeniKolonuBaze.boja.Text = reader["Boja"].ToString();
                            izmeniKolonuBaze.brojSasije.Text = reader["BrojSasije"].ToString();
                            izmeniKolonuBaze.brojMotora.Text = reader["BrojMotora"].ToString();
                            izmeniKolonuBaze.snagaMotora.Text = reader["SnagaMotora"].ToString();
                            izmeniKolonuBaze.masaVozila.Text = reader["Masa"].ToString();
                            izmeniKolonuBaze.zapreminaMotora.Text = reader["ZapreminaMotora"].ToString();
                            izmeniKolonuBaze.nosivostVozila.Text = reader["NosivostVozila"].ToString();
                            izmeniKolonuBaze.odnosSnagaMasa.Text = reader["OdnosSnagaMasa"].ToString();
                            izmeniKolonuBaze.brojOsovina.Text = reader["BrojOsovina"].ToString();
                            izmeniKolonuBaze.najvecaDozovljenaMasa.Text = reader["NajvecaDozvoljenaMasa"].ToString();
                            izmeniKolonuBaze.brojMestaZaSedenje.Text = reader["BrojMestaZaSedenje"].ToString();
                            izmeniKolonuBaze.brojMestaZaStajanje.Text = reader["BrojMestaZaStajanje"].ToString();
                            izmeniKolonuBaze.homologacijskaOznaka.Text = reader["HomologacijskaOznaka"].ToString();
                            izmeniKolonuBaze.vrstaVozila.Text = reader["VrstaVozila"].ToString();
                            izmeniKolonuBaze.pogonskoGorivo.Text = reader["PogonskoGorivo"].ToString();
                        }
                    }
                }
            }

            izmeniKolonuBaze.Show();
        }

        public object GetSelectedRowData()
        {
            if (prikazIzBaze.SelectedItems.Count > 0)
            {
                DataRowView selectedRow = (DataRowView)prikazIzBaze.SelectedItems[0];
                return selectedRow["PodaciID"];
            }
            return null;
        }

    }
}
