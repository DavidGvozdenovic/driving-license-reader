﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CitacSaobracajneV1._2
{
    /// <summary>
    /// Interaction logic for Osiguranja.xaml
    /// </summary>
    public partial class Osiguranja : Window
    {
        MainWindow glavniProzor = new MainWindow();

        public Osiguranja()
        {
            InitializeComponent();
            //ispisiBazuOsiguravajucihKuca();
            //ispisiBazuTipovaOsiguranja();
        }

        private void DodajOsiguravajucuKucu_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(imeOsiguravajuceKuce.Text) || string.IsNullOrEmpty(sifraOsiguravajuceKuce.Text))
            {
                MessageBox.Show("Obavezna polja su označena zvezdicom i moraju biti ispunjena!", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            else
            {
                //string imeUneteBaze = glavniProzor.imeBaze.Text;
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.DataSource = "PERIC - PC";
                builder.InitialCatalog = "CitacSaobracajne";
                builder.IntegratedSecurity = true;

                //pravljenje konekcije sa unetim imenom servera
                SqlConnection connection = new SqlConnection(builder.ToString());
                connection.Open();
                SqlCommand command = new SqlCommand("insert into OsiguravajucaKuca (Sifra,Naziv) values" + "(@Sifra,@Naziv)", connection);
                command.Parameters.AddWithValue("@Sifra", sifraOsiguravajuceKuce.Text);
                command.Parameters.AddWithValue("@Naziv", imeOsiguravajuceKuce.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Osiguravajuca kuca uspesno upisana u bazu.", "Uspesna komunikacija", MessageBoxButton.OK, MessageBoxImage.Information);
                ispisiBazuOsiguravajucihKuca();
            }


        }
        private void DodajTipOsiguranja_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(imeTipaOsiguranja.Text) || string.IsNullOrEmpty(sifraTipaOsiguranja.Text))
            {
                MessageBox.Show("Obavezna polja su označena zvezdicom i moraju biti ispunjena!", "Greška", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            else
            {
                //string imeUneteBaze = glavniProzor.imeBaze.Text;
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
                builder.DataSource = "PERIC - PC";
                builder.InitialCatalog = "CitacSaobracajne";
                builder.IntegratedSecurity = true;

                //pravljenje konekcije sa unetim imenom servera
                SqlConnection connection = new SqlConnection(builder.ToString());
                connection.Open();
                SqlCommand command = new SqlCommand("insert into TipoviOsiguranja (Sifra,Naziv) values" + "(@Sifra,@Naziv)", connection);
                command.Parameters.AddWithValue("@Sifra", sifraTipaOsiguranja.Text);
                command.Parameters.AddWithValue("@Naziv", imeTipaOsiguranja.Text);
                command.ExecuteNonQuery();
                MessageBox.Show("Osiguravajuca kuca uspesno upisana u bazu.", "Uspesna komunikacija", MessageBoxButton.OK, MessageBoxImage.Information);
                ispisiBazuTipovaOsiguranja();
            }
        }


        private void PodaciOSaobracajnojWindow_Click(object sender, RoutedEventArgs e)
        {

            glavniProzor.Show();
            this.Close();
        }


        private void ispisiBazuOsiguravajucihKuca()
        {
            //string imeUneteBaze = glavniProzor.imeBaze.Text;

            string connectionString = "Data Source=PERIC-PC;Initial Catalog=CitacSaobracajne;Integrated Security=True";
            //connectionString = connectionString.Replace("Data Source=PERIC-PC", "Data Source=" + imeUneteBaze);
            string query = "SELECT * FROM OsiguravajucaKuca";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);

                    prikazIzBazeOsiguravajuceKuce.ItemsSource = dataTable.DefaultView;
                }
            }
        }
        private void ispisiBazuTipovaOsiguranja()
        {
            //string imeUneteBaze = glavniProzor.imeBaze.Text;

            string connectionString = "Data Source=PERIC-PC;Initial Catalog=CitacSaobracajne;Integrated Security=True";
            //connectionString = connectionString.Replace("Data Source=PERIC-PC", "Data Source=" + imeUneteBaze);
            string query = "SELECT * FROM TipoviOsiguranja";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);

                    prikazIzBazeTipoviOsiguranja.ItemsSource = dataTable.DefaultView;
                }
            }
        }




        private void IzbrisiIzBazeOsiguravajucihKuca_Click(object sender, RoutedEventArgs e)
        {
            var selectedRows = prikazIzBazeOsiguravajuceKuce.SelectedItems;
            if (selectedRows.Count == 0)
            {
                MessageBox.Show("Niste izabrali nijednu kolonu.", "Upozorenje", MessageBoxButton.OK, MessageBoxImage.Information);

                // Handle the case where no row is selected
                return;
            }
            int selectedRowID = (int)((DataRowView)selectedRows[0]).Row["OsiguravajucaKucaID"];

            //unos imena servera preko textboxa
            //string imeUneteBaze = glavniProzor.imeBaze.Text;
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            //builder.DataSource = imeUneteBaze;
            builder.InitialCatalog = "CitacSaobracajne";
            builder.IntegratedSecurity = true;

            //pravljenje konekcije sa unetim imenom servera
            //SqlConnection connection = new SqlConnection(builder.ToString());
            using (SqlConnection connection = new SqlConnection(builder.ToString()))
            {
                connection.Open();

                string deleteQuery = "DELETE FROM OsiguravajucaKuca WHERE OsiguravajucaKucaID = @SelectedRowID";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@SelectedRowID", selectedRowID);
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Izabrana kolona uspesno obrisana.", "Uspesno", MessageBoxButton.OK, MessageBoxImage.Information);
                        ispisiBazuOsiguravajucihKuca();
                        // The row was successfully deleted
                        // You can also update the DataGrid to reflect the change in the UI
                        // Reload the data or remove the deleted row from your data source.
                    }
                    else
                    {

                        // Handle the case where no rows were deleted (e.g., the ID didn't exist)
                    }
                }
            }
        }

        private void IzbrisiIzBazeTipovaOsiguranja_Click(object sender, RoutedEventArgs e)
        {
            var selectedRows = prikazIzBazeTipoviOsiguranja.SelectedItems;
            if (selectedRows.Count == 0)
            {
                MessageBox.Show("Niste izabrali nijednu kolonu.", "Upozorenje", MessageBoxButton.OK, MessageBoxImage.Information);

                // Handle the case where no row is selected
                return;
            }
            int selectedRowID = (int)((DataRowView)selectedRows[0]).Row["TipoviOsiguranjaID"];

            //unos imena servera preko textboxa
            //string imeUneteBaze = glavniProzor.imeBaze.Text;
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            //builder.DataSource = imeUneteBaze;
            builder.InitialCatalog = "CitacSaobracajne";
            builder.IntegratedSecurity = true;

            //pravljenje konekcije sa unetim imenom servera
            //SqlConnection connection = new SqlConnection(builder.ToString());
            using (SqlConnection connection = new SqlConnection(builder.ToString()))
            {
                connection.Open();

                string deleteQuery = "DELETE FROM TipoviOsiguranja WHERE TipoviOsiguranjaID = @SelectedRowID";

                using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@SelectedRowID", selectedRowID);
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Izabrana kolona uspesno obrisana.", "Uspesno", MessageBoxButton.OK, MessageBoxImage.Information);
                        ispisiBazuTipovaOsiguranja();
                        // The row was successfully deleted
                        // You can also update the DataGrid to reflect the change in the UI
                        // Reload the data or remove the deleted row from your data source.
                    }
                    else
                    {

                        // Handle the case where no rows were deleted (e.g., the ID didn't exist)
                    }
                }
            }
        }


        private void PrometWindow_Click(object sender, RoutedEventArgs e)
        {
            Promet promet = new Promet();
            promet.Show();
            this.Close();
        }


    }
}
