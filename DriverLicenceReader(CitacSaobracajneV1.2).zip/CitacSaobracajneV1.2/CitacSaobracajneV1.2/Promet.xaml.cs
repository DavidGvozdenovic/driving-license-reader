﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CitacSaobracajneV1._2
{
    /// <summary>
    /// Interaction logic for Promet.xaml
    /// </summary>
    public partial class Promet : Window
    {
        MainWindow glavniProzor = new MainWindow();
        public Promet()
        {
            InitializeComponent();
        }

        private void PodaciOSaobracajnojWindow_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void OsiguranjaWindow_Click(object sender, RoutedEventArgs e)
        {
            Osiguranja svaOsiguranja = new Osiguranja();
            svaOsiguranja.Show();
            this.Close();
        }


        private void PretraziBazu_Click(object sender, RoutedEventArgs e)
        {
            string imeUneteBaze = "PERIC - PC";
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
            builder.DataSource = imeUneteBaze;
            builder.InitialCatalog = "CitacSaobracajne";
            builder.IntegratedSecurity = true;

            string searchText = sifraVozila.Text;

            using (SqlConnection connection = new SqlConnection(builder.ToString()))
            {
                connection.Open();

                // Create a SQL query to search for the record
                string query = "SELECT RegistarskiBroj FROM PodaciSaobracajneDozvole WHERE " +
                               "BrojDokumenta = @searchText OR " +
                               "ImeVlasnika = @searchText OR " +
                               "Model = @searchText ";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@searchText", searchText);

                    // Execute the query
                    string registarskiBroj = (string)cmd.ExecuteScalar();

                    if (string.IsNullOrEmpty(registarskiBroj))
                    {
                        osnovniPodaci.Text = "Nema regisatrskih podataka za unetu sifru.";
                    }
                    else
                    {
                        osnovniPodaci.Text = "Vlasnik:\t" + "JMBG Vlasnika: \n" + "Broj dokumenta: " + "Registarski broj: " + registarskiBroj + "\nMarka/Model: " + "Godina proizovdnje: "+"\nBroj sasije: "+"Broj motora: "+"\nVrsta vozila: "+"Pogonsko gorivo: ";

                    }
                    // Set the text of the osnovniPodaci TextBox
                }
            }
        }
    }
}
